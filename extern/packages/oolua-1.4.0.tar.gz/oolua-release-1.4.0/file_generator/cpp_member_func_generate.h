#ifndef CPP_MEMBER_FUNC_GENERATE_H_
#	define CPP_MEMBER_FUNC_GENERATE_H_

void cpp_member_func_header(std::string & save_directory,int noOfParams);
#endif
