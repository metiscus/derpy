#ifndef LUA_FUNCTION_GENERATE_H_
#	define LUA_FUNCTION_GENERATE_H_

void lua_function_header(std::string & save_directory,int maxParams);

#endif