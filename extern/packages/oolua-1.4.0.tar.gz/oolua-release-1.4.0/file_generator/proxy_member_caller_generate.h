#ifndef POXY_MEMBER_CALLER_GENERATE_H_
#	define POXY_MEMBER_CALLER_GENERATE_H_

void proxy_member_caller_header(std::string & save_directory,int paramCount);

#endif
