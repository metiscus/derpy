#ifndef OOLUA_CONSTRUCOTOR_GENERATE_H
#	define OOLUA_CONSTRUCOTOR_GENERATE_H
#include <string>

void constructor_header(std::string & save_directory,int paramCount);

#endif
