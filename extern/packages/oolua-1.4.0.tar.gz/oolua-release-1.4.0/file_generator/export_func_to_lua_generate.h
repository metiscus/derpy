
#ifndef EXPORT_FUNC_TO_LUA_GENERATE_H_
#	define EXPORT_FUNC_TO_LUA_GENERATE_H_

void export_func_to_lua_header(std::string & save_directory,int amount);

#endif