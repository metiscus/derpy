#ifndef CPP_STUB_CLASSES_OOLUA_H_
#	define CPP_STUB_CLASSES_OOLUA_H_

struct Stub1 {};
struct Stub2 {};
struct Stub3 {};
struct InvalidStub {};
struct Return_double{};


#endif
