#ifndef CPP_CLASS_IN_NAMESPACE_H_
#	define CPP_CLASS_IN_NAMESPACE_H_

namespace TEST_NAMESPACED_CLASS
{
	struct Namespaced{};
}

#endif

