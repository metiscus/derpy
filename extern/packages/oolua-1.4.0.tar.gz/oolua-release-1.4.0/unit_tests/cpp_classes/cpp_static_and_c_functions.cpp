#include "cpp_static_and_c_functions.h"

