#ifndef CPP_CLASS_ENUMS_H_
#	define CPP_CLASS_ENUMS_H_

struct ClassWithEnums
{
	enum  {
		UNNAMED_ENUM_0
		,UNNAMED_ENUM_1
	};
	enum ClassEnum
	{
		ENUM_0
		,ENUM_1
	};
};

#endif

