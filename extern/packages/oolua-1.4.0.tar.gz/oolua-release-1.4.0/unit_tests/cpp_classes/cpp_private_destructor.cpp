
#include "cpp_private_destructor.h"

EXPORT_OOLUA_NO_FUNCTIONS(PrivateDestructor)

