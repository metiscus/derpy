#include "lua_class_ops.h"

EXPORT_OOLUA_FUNCTIONS_0_NON_CONST(Class_ops)
EXPORT_OOLUA_FUNCTIONS_1_CONST(Class_ops,geti)
