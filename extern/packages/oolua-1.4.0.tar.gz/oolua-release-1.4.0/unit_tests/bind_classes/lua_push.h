#ifndef LUA_PUSH_H_
#	define LUA_PUSH_H_

#	include "oolua.h"
#	include "cpp_push.h"

/*
OOLUA_CLASS_NO_BASES(Push)
OOLUA_NO_TYPEDEFS
	OOLUA_ONLY_DEFAULT_CONSTRUCTOR
OOLUA_MEM_FUNC_0(Push&,ref)
OOLUA_MEM_FUNC_0(Push const&,ref_const)
OOLUA_MEM_FUNC_0(Push*,ptr)
OOLUA_MEM_FUNC_0(Push const*,ptr_const)
*/
//OOLUA_MEM_FUNC_0(Push const*/*const*/, const_ptr_const)
/*
OOLUA_MEM_FUNC_0_CONST(void,const_func)
OOLUA_MEM_FUNC_0(int, int_value)
OOLUA_MEM_FUNC_0(int&, int_ref)
OOLUA_MEM_FUNC_0(int*, int_ptr)
OOLUA_MEM_FUNC_0(int const&, int_ref_const)
OOLUA_MEM_FUNC_0(int const *const&,int_ref_const_ptr_const)
OOLUA_MEM_FUNC_0(int const*&,int_ref_ptr_const)
OOLUA_PUBLIC_MEMBER_GET_SET(i_)
OOLUA_CLASS_END
*/


#endif//LUA_PUSH_H_
