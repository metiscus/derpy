#include "expose_class_enums.h"

EXPORT_OOLUA_NO_FUNCTIONS(ClassWithEnums)
