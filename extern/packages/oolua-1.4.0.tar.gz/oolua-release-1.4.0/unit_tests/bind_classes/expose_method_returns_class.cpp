#include "expose_method_returns_class.h"


EXPORT_OOLUA_FUNCTIONS_8_NON_CONST(Method_returns_class
								   ,ref
								   ,ref_const
								   ,ptr
								   ,ptr_const
								   ,ref_ptr_const
								   ,ref_const_ptr_const
								   ,return_stack_instance
								   ,returns_null)

EXPORT_OOLUA_FUNCTIONS_0_CONST(Method_returns_class)
