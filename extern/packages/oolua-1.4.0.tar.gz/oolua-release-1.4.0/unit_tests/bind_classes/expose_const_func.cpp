#include "expose_const_func.h"


EXPORT_OOLUA_FUNCTIONS_1_NON_CONST(Constant,cpp_func)
EXPORT_OOLUA_FUNCTIONS_1_CONST(Constant,cpp_func_const)

