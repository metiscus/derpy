#include "expose_enum.h"

EXPORT_OOLUA_FUNCTIONS_CONST(Enums)
EXPORT_OOLUA_FUNCTIONS_NON_CONST(Enums
								 ,set_enum
								 ,get_enum
								 )

