#include "expose_namespaced_class.h"

EXPORT_OOLUA_NO_FUNCTIONS(Namespaced)


