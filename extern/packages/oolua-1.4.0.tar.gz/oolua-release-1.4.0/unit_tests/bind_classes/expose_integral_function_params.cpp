#include "expose_integral_function_params.h"

EXPORT_OOLUA_FUNCTIONS_8_NON_CONST(Int_params
								   ,int_
								   ,int_ref
								   ,int_ptr
								   ,int_const
								   ,int_const_ref
								   ,int_const_ptr
								   ,int_const_ptr_const
								   ,bool_)

EXPORT_OOLUA_FUNCTIONS_0_CONST(Int_params)
