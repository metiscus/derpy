#include "lua_push.h"
/*

EXPORT_OOLUA_FUNCTIONS_12_NON_CONST(Push,
							ref,
							ref_const,
							ptr,
							ptr_const,
							const_ptr_const,
							int_value,
							int_ref,
							int_ptr,
							int_ref_const,
							set_i_,
							int_ref_const_ptr_const,
							int_ref_ptr_const
						)
EXPORT_OOLUA_FUNCTIONS_2_CONST(Push,const_func,get_i_)
*/
