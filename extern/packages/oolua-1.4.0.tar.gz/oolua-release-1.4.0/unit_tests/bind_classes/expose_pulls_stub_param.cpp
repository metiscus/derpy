#include "expose_pulls_stub_param.h"

EXPORT_OOLUA_FUNCTIONS_7_NON_CONST(Pulls_stub
								   ,ref
								   ,ref_const
								   ,ref_ptr_const
								   ,ref_const_ptr_const
								   ,ptr
								   ,ptr_const
								   ,const_ptr_const
								   )
EXPORT_OOLUA_FUNCTIONS_0_CONST(Pulls_stub)