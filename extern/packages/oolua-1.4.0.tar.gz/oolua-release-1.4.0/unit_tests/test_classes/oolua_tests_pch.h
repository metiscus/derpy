#ifndef OOLUA_TESTS_PCH_H_
#	define OOLUA_TESTS_PCH_H_

#	ifdef OOLUA_USE_PRECOMPILED_HEADER
//#		include "oolua.h"
#		include "common_cppunit_headers.h"
#		include "gmock/gmock.h"
#	endif

#endif
